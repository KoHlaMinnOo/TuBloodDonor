const connection = new WebSocket('ws://localhost:8081');

connection.onopen = () => {
    console.log(
        "Connected to Siginaling server."
    )
}

connection.onmessage = message => {
    console.log("Got Message ", message.data);
    var data = JSON.parse(message.data);
    switch (data.type) {
        case 'login':
            handleLogin(data.success)
            break;
        case 'offer':
            handleOffer(data.offer, data.name)
            break;
        case 'answer':
            handleAnswer(data.answer)
            break;
        case 'candidate':
            handleCandidate(data.candidate)
            break;
        default:
            break;
    }
}
connection.onerror = error => {
    console.error(error);
}

var myName, otherName;
let myConnection;
var connectedUser;
var stream;

var loginPage = document.querySelector('#loginPage');
var usernameInput = document.querySelector('#usernameInput');
var loginBtn = document.querySelector('#loginBtn');

var callPage = document.querySelector('#callPage');
var callToUsernameInput = document.querySelector('#callToUsernameInput');
var callBtn = document.querySelector('#callBtn');

var hangUpBtn = document.querySelector('#hangUpBtn');

var localVideo = document.querySelector('#localVideo');
var remoteVideo = document.querySelector('#remoteVideo');

loginPage.style.display = "block";
callPage.style.display = "none";
loginBtn.addEventListener('click', () => {
    myName = usernameInput.value;

    if (myName.length > 0) {
        send({
            type: 'login',
            name: myName
        })
    }
})


function send(message) {

    if (connectedUser) {
        message.name = connectedUser
    }

    connection.send(JSON.stringify(message));
}

function handleLogin(success) {
    if (success === false) {
        alert("Error , try width different username.");
    } else {
        loginPage.style.display = "none";
        callPage.style.display = "block";


        navigator.getUserMedia({ video: true },
            function(myStream) {
                stream = myStream;
                localVideo.srcObject = stream;

                var configuration = {
                    "iceServers": [{ "url": "stun:stun2.1.google.com:19302" }]
                };
                myConnection = new RTCPeerConnection(configuration);

                myConnection.addStream(stream);

                myConnection.onaddstream = e => {
                    remoteVideo.srcObject = e.stream;
                }

                myConnection.onicecandidate = event => {
                    if (event.candidate) {
                        send({
                            type: 'candidate',
                            candidate: event.candidate
                        })
                    }
                }

            }, error => {
                console.error("error media")
            }
        );
    }
}

callBtn.addEventListener('click', () => {
    otherName = callToUsernameInput.value;
    if (otherName.length > 0) {
        connectedUser = otherName;

        myConnection.createOffer(
            offer => {
                send({
                    type: 'offer',
                    offer: offer
                });
                myConnection.setLocalDescription(offer);
            },
            error => {
                console.error("offer error", error);
            }
        );
    }
});

function handleOffer(offer, name) {
    connectedUser = name;
    myConnection.setRemoteDescription(new RTCSessionDescription(offer));
    myConnection.createAnswer(
        answer => {
            myConnection.setLocalDescription(answer);
            send({
                type: 'answer',
                answer: answer
            });
        },
        error => {
            alert("error when ansering");
        }
    );
}

function handleAnswer(answer) {
    myConnection.setRemoteDescription(new RTCSessionDescription(answer));

}

function handleCandidate(candidate) {
    myConnection.addIceCandidate(new RTCIceCandidate(candidate));
}

hangUpBtn.addEventListener('click', () => {
    send({
        type: 'leave'
    });
    handleLeave();
})

function handleLeave() {
    connectedUser = null;
    remoteVideo.srcObject = null;
    myConnection.close();
    myConnection.onicecandidate = null;
    myConnection.addStream = null;
}