var WebSocketServer = require('ws').Server;
const wss = new WebSocketServer({ port: 8081 });
var user = {};


wss.on("connection", connection => {

    console.log("user connected");
    connection.on("message", message => {
        var data;

        try {
            data = JSON.parse(message);
            console.log(data);
        } catch (error) {
            console.log("connection message", error);
        }
        switch (data.type) {
            case 'login':
                console.log(data.name, "login");
                if (user[data.name]) {
                    sendTo(connection, {
                        type: 'login',
                        success: false
                    });
                } else {
                    user[data.name] = connection;
                    connection.name = data.name;
                    sendTo(connection, {
                        type: 'login',
                        success: true
                    });
                }
                break;

            case 'offer':
                console.log("Sending offer to", data.name);
                var conn = user[data.name];

                if (conn != null) {
                    connection.otherName = data.name;
                    console.log("connection.name", connection.name);
                    sendTo(conn, {
                        type: 'offer',
                        offer: data.offer,
                        name: connection.name
                    });
                }
                break;
            case 'answer':
                console.log("Sending anser to ", data.name);
                var conn = user[data.name];

                if (conn != null) {
                    connection.otherName = data.name;
                    sendTo(conn, {
                        type: 'answer',
                        answer: data.answer
                    });
                }
                break;
            case 'candidate':
                console.log("Sending candidate to ", data.name);
                var conn = user[data.name];

                if (conn != null) {
                    sendTo(conn, {
                        type: 'candidate',
                        candidate: data.candidate
                    });
                }
                break;
            case 'leave':
                console.log("Disconnected from ", data.name);
                var conn = user[data.name];
                conn.otherName = null;
                if (conn != null) {
                    sendTo(conn, {
                        type: 'leave'
                    });
                }
                break;
            default:
                sendTo(connection, {
                    type: 'error',
                    message: "Command not found " + data.type
                });
                break;
        }

    });

    connection.on("close", () => {
        if (connection.name) {
            delete user[connection.name];
        }

        if (connection.otherName) {
            console.log("Disconnecting from ", connection.otherName);
            var conn = user[connection.otherName];
            if (conn != null) {
                sendTo(conn, {
                    type: 'leave'
                })
            }
        }
    })
});

function sendTo(connection, message) {
    connection.send(JSON.stringify(message));
}