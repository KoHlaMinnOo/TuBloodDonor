# WebRTC
 Web based Video chat App with WebRTC using Scaledrone Realtime Messaging Service <br>
 Share the URL of the webpage to the recipient to enable a handshake and attempt a connect

## Demo:
 * [Live Demo](https://painlessdeath09.github.io/WebRTC/index.html)
